pluginManagement {
    repositories {
        google()
        gradlePluginPortal()
        mavenCentral()
        maven(url = "https://jitpack.io") // ⬅️ Tambahin ini bro
    }
}

dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
        maven(url = "https://jitpack.io") // ⬅️ Tambahin juga di sini
    }
}

rootProject.name = "FarizRamadhani"
include(":app")
