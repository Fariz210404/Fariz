package com.example.farizramadhani;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.tasks.Task;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SmsAutofillActivity extends AppCompatActivity {

    EditText etOtp;
    TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smsautofill);

        etOtp = findViewById(R.id.et_otp);
        tvStatus = findViewById(R.id.tv_status);

        startSmsListener();
    }

    private void startSmsListener() {
        Task<Void> task = SmsRetriever.getClient(this).startSmsRetriever();
        task.addOnSuccessListener(aVoid -> tvStatus.setText("Menunggu OTP via SMS..."));
        task.addOnFailureListener(e -> tvStatus.setText("Gagal memulai SMS Retriever"));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 123 && resultCode == RESULT_OK && data != null) {
            String message = data.getStringExtra(SmsRetriever.EXTRA_SMS_MESSAGE);
            if (message != null) {
                String otp = extractOTP(message);
                etOtp.setText(otp);
                tvStatus.setText("Kode OTP diterima");
            }
        }
    }

    private String extractOTP(String message) {
        Pattern pattern = Pattern.compile("\\b\\d{4,6}\\b");
        Matcher matcher = pattern.matcher(message);
        return matcher.find() ? matcher.group(0) : "";
    }
}
