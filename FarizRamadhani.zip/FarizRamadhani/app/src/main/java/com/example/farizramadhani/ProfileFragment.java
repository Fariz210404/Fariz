package com.example.farizramadhani;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.*;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {

    TextView tvUsername, tvKota;
    Button btnLogout;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        tvUsername = view.findViewById(R.id.tv_username);
        tvKota = view.findViewById(R.id.tv_kota);
        btnLogout = view.findViewById(R.id.btn_logout);

        // Ambil data dari SharedPreferences
        SharedPreferences prefs = requireActivity().getSharedPreferences("userPrefs", android.content.Context.MODE_PRIVATE);
        String username = prefs.getString("username", "User");
        String kota = prefs.getString("kota", "Kota tidak diketahui");

        // Set ke TextView
        tvUsername.setText(username);
        tvKota.setText(kota);

        // Tombol logout
        btnLogout.setOnClickListener(v -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.clear(); // hapus semua data
            editor.apply();

            // Arahkan ke LoginActivity
            requireActivity().startActivity(
                    new android.content.Intent(getActivity(), LoginActivity.class)
            );
            requireActivity().finish();
        });

        return view;
    }
}
