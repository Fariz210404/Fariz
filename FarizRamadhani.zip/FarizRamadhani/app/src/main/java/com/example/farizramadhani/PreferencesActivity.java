package com.example.farizramadhani;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class PreferencesActivity extends AppCompatActivity {

    EditText etNama;
    Button btnSimpan;
    TextView tvHasil;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preferences);

        etNama = findViewById(R.id.et_nama);
        btnSimpan = findViewById(R.id.btn_simpan);
        tvHasil = findViewById(R.id.tv_hasil);

        sharedPreferences = getSharedPreferences("myPrefs", MODE_PRIVATE);

        // Tampilkan nama sebelumnya (kalau ada)
        String namaTersimpan = sharedPreferences.getString("nama", "Belum ada data");
        tvHasil.setText("Nama tersimpan: " + namaTersimpan);

        btnSimpan.setOnClickListener(v -> {
            String nama = etNama.getText().toString();
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("nama", nama);
            editor.apply();

            tvHasil.setText("Nama tersimpan: " + nama);
        });
    }
}
