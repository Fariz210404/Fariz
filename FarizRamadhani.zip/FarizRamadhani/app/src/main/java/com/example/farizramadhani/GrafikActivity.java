package com.example.farizramadhani;

import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;

import java.util.ArrayList;

public class GrafikActivity extends AppCompatActivity {

    private BarChart barChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grafik);

        barChart = findViewById(R.id.barChart);

        // Data dummy
        ArrayList<BarEntry> entries = new ArrayList<>();
        entries.add(new BarEntry(1f, 5));
        entries.add(new BarEntry(2f, 8));
        entries.add(new BarEntry(3f, 6));
        entries.add(new BarEntry(4f, 2));
        entries.add(new BarEntry(5f, 9));

        BarDataSet dataSet = new BarDataSet(entries, "Data Mingguan");
        dataSet.setColors(Color.BLUE);
        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setValueTextSize(16f);

        BarData barData = new BarData(dataSet);
        barChart.setData(barData);

        Description desc = new Description();
        desc.setText("Grafik Pengunjung");
        barChart.setDescription(desc);
        barChart.animateY(1000);
    }
}
