package com.example.farizramadhani;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.Button;
import androidx.fragment.app.Fragment;

public class MenuFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_menu, container, false);

        view.findViewById(R.id.btn_camera).setOnClickListener(v ->
                startActivity(new Intent(getActivity(), CameraActivity.class)));

        view.findViewById(R.id.btn_grafik).setOnClickListener(v ->
                startActivity(new Intent(getActivity(), GrafikActivity.class)));

        view.findViewById(R.id.btn_map).setOnClickListener(v ->
                startActivity(new Intent(getActivity(), MapActivity.class)));

        view.findViewById(R.id.btn_preferences).setOnClickListener(v ->
                startActivity(new Intent(getActivity(), PreferencesActivity.class)));

        view.findViewById(R.id.btn_sms).setOnClickListener(v ->
                startActivity(new Intent(getActivity(), SmsAutofillActivity.class)));

        view.findViewById(R.id.btn_spinner).setOnClickListener(v ->
                startActivity(new Intent(getActivity(), SpinnerActivity.class)));

        view.findViewById(R.id.btn_thread).setOnClickListener(v ->
                startActivity(new Intent(getActivity(), ThreadAsyncActivity.class)));

        return view;
    }
}
