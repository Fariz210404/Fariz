package com.example.farizramadhani;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SpinnerActivity extends AppCompatActivity {

    AutoCompleteTextView autoInput;
    Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spinner);

        autoInput = findViewById(R.id.auto_input);
        btnSubmit = findViewById(R.id.btn_submit); // Tambahan tombol submit

        // Data dummy: daftar jurusan
        String[] jurusan = new String[] {
                "Teknik Komputer dan Jaringan",
                "Rekayasa Perangkat Lunak",
                "Bisnis dan Pemasaran",
                "Akuntansi Keuangan",
                "Administrasi Perkantoran",
                "Multimedia",
                "Farmasi",
                "Perhotelan",
                "Teknik Sepeda Motor"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                jurusan
        );

        autoInput.setAdapter(adapter);

        // Event tombol Submit
        btnSubmit.setOnClickListener(v -> {
            String selected = autoInput.getText().toString().trim();
            if (!selected.isEmpty()) {
                Toast.makeText(this, "Submit berhasil: " + selected, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Silakan pilih jurusan atau kota dulu!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
