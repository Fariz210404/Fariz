package com.example.farizramadhani;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.google.android.gms.auth.api.phone.SmsRetriever;

public class SmsReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (SmsRetriever.SMS_RETRIEVED_ACTION.equals(intent.getAction())) {
            Bundle extras = intent.getExtras();
            if (extras != null) {
                int status = extras.getInt("com.google.android.gms.auth.api.phone.EXTRA_STATUS");
                if (status == 0) { // SUCCESS
                    String message = extras.getString(SmsRetriever.EXTRA_SMS_MESSAGE);
                    Intent intent1 = new Intent(context, SmsAutofillActivity.class);
                    intent1.putExtra(SmsRetriever.EXTRA_SMS_MESSAGE, message);
                    ((Activity) context).startActivityForResult(intent1, 123);
                }
            }
        }
    }
}
