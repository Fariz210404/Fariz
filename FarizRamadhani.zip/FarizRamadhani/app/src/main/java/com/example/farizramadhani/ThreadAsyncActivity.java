package com.example.farizramadhani;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ThreadAsyncActivity extends AppCompatActivity {

    ProgressBar progressBar;
    TextView tvStatus;
    Button btnLoad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_threadasync);

        progressBar = findViewById(R.id.progressBar);
        tvStatus = findViewById(R.id.tv_status);
        btnLoad = findViewById(R.id.btn_load);

        btnLoad.setOnClickListener(v -> new LoadTask().execute());
    }

    private class LoadTask extends AsyncTask<Void, Integer, String> {
        @Override
        protected void onPreExecute() {
            progressBar.setVisibility(View.VISIBLE);
            tvStatus.setText("Status: Loading dimulai...");
            btnLoad.setEnabled(false);
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                for (int i = 1; i <= 100; i += 20) {
                    Thread.sleep(500); // delay 0.5 detik
                    publishProgress(i);
                }
            } catch (InterruptedException e) {
                return "Gagal: " + e.getMessage();
            }
            return "Selesai!";
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            progressBar.setProgress(values[0]);
            tvStatus.setText("Status: " + values[0] + "%");
        }

        @Override
        protected void onPostExecute(String result) {
            progressBar.setVisibility(View.GONE);
            tvStatus.setText("Status: " + result);
            btnLoad.setEnabled(true);
        }
    }
}
