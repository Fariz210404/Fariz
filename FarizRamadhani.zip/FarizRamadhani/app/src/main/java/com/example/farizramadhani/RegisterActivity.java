package com.example.farizramadhani;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    EditText etUsername, etPassword, etKota;
    Button btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etUsername = findViewById(R.id.et_username);
        etPassword = findViewById(R.id.et_password);
        etKota = findViewById(R.id.et_kota);
        btnRegister = findViewById(R.id.btn_register);

        SharedPreferences prefs = getSharedPreferences("userPrefs", MODE_PRIVATE);

        btnRegister.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString().trim();
            String kota = etKota.getText().toString().trim();

            if (!username.isEmpty() && !password.isEmpty() && !kota.isEmpty()) {
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("username", username);
                editor.putString("password", password);
                editor.putString("kota", kota);
                editor.putBoolean("isLoggedIn", true);
                editor.apply();

                Toast.makeText(this, "Register berhasil!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, MainActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Semua kolom harus diisi!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
